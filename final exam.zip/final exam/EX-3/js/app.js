const app = Vue.createApp({
    data() {
        return {
            rest_api: "https://finalexamapi.herokuapp.com/api/teachers",
            listOfPeople: []
        }
    },
    methods: {
        fetchData(){
            axios.get(this.rest_api).then((response)=>{
                this.listOfPeople = response.data.filter((position) => position.position == "Trainer");
            })
        }
    },
    mounted() {
        this.fetchData();
    },
    computed: {
        displayData(){
            return this.listOfPeople;
        }
    }
});
app.mount('#app');