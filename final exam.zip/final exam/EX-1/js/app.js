const app = Vue.createApp({
    data() {
        return {
            taskName: "",
            selectedOption: "green",
            listOfTasks: [],
        }
    },
    methods: {
        addNewTask(){
            if (this.taskName.trim() != "" && this.priority != ""){
                this.listOfTasks.push({name: this.taskName, priority: this.selectedOption})
            }
        }
    },
    mounted() {
        this.addNewTask();
    },
    computed: {
        numberOfNormal(){
            let amountOfNormal = this.listOfTasks.filter((task)=>task.priority == "green");
            if (amountOfNormal.length != 0){
                return amountOfNormal.length
            }
        },
        numberOfHigh(){
            let amountOfHigh = this.listOfTasks.filter((task)=>task.priority == "red");
            if (amountOfHigh.length != 0){
                return amountOfHigh.length
            }
        },
        numberOfDocument(){
            let amountOfDocument = this.listOfTasks.filter((task)=>task.priority == "blue");
            if (amountOfDocument.length != 0){
                return amountOfDocument.length
            }
        },
        numberOfNiceToHave(){
            let amountOfNiceToHave = this.listOfTasks.filter((task)=>task.priority == "orange");
            if (amountOfNiceToHave.length != 0 ){
                return amountOfNiceToHave.length;
            }
        },
    }
});
app.mount('#app');