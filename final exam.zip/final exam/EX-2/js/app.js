const app = Vue.createApp({
    data() {
        return {
            listOfScores: [] ,
            subjectName: "",
            score: null,
        }
    },
    methods: {
        addScore(){
            if (this.subjectName.trim() != " " && this.score != null){
                this.listOfScores.push({subject: this.subjectName, score: this.score})
                this.subjectName = "";
                this.score = null;
            }
        }
    },
    mounted() {
        this.addScore();
    },
    computed: {
        maxScore(){
            let score = 0;
            for (let subject of this.listOfScores){
                if (score < subject.score){
                    score = subject.score;
                }
            }
            if (score != 0){
                return score;
            }
        },
        minScore(){
            let score = 100;
            for (let subject of this.listOfScores){
                if (score > subject.score){
                    score = subject.score;
                }
            }
            if (score != 100){
                return score;
            }
        },
        average(){
            let total = 0;
            for (let subject of this.listOfScores){
                total += subject.score;
            }
            if (total != 0){
                return total/this.listOfScores.length;
            }
        }
    }
});
app.mount('#app');